function pad(num, size) {
	var s = "000000000" + num;
	return s.substr(s.length-size);
}

function attSerialCallback(data) {
	console.log("aaaa callback serial: " + data);
}
